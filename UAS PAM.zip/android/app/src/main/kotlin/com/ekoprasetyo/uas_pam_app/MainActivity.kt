package com.ekoprasetyo.uas_pam_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
